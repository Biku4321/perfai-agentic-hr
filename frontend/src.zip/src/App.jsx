import { useState } from 'react'
import HRView from './pages/HRView'
import ManagerView from './pages/ManagerView'
import EmployeeView from './pages/EmployeeView'
import AgentChat from './components/Chat/AgentChat'
import './App.css'

function App() {
  const [activeTab, setActiveTab] = useState('manager')

  return (
    <div className="min-h-screen bg-[#0a0b0e] text-[#e8ecf0] font-sans pb-20">
      {/* Navigation Bar */}
      <nav className="border-b border-[#1f2530] bg-[#111318] sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[#00d4aa] flex items-center justify-center text-black font-bold">
              P
            </div>
            <span className="font-display font-bold text-lg tracking-wide text-white">PerfAI</span>
            <span className="ml-2 text-xs text-[#6b7a8d] border border-[#2a3545] px-2 py-0.5 rounded-full">
              on effiHR
            </span>
          </div>
          
          <div className="flex gap-1 bg-[#181c24] p-1 rounded-lg border border-[#1f2530] overflow-x-auto">
            <button 
              onClick={() => setActiveTab('hr')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${activeTab === 'hr' ? 'bg-[#2a3545] text-white shadow' : 'text-[#6b7a8d] hover:text-white'}`}
            >
              HR Admin
            </button>
            <button 
              onClick={() => setActiveTab('manager')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${activeTab === 'manager' ? 'bg-[#2a3545] text-white shadow' : 'text-[#6b7a8d] hover:text-white'}`}
            >
              Manager View
            </button>
            <button 
              onClick={() => setActiveTab('employee')}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${activeTab === 'employee' ? 'bg-[#2a3545] text-white shadow' : 'text-[#6b7a8d] hover:text-white'}`}
            >
              Employee View
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {activeTab === 'hr' && <HRView />}
        {activeTab === 'manager' && <ManagerView />}
        {activeTab === 'employee' && <EmployeeView />}
      </main>

      {/* Global Floating Agent Chat */}
      <AgentChat currentContext={activeTab} />

      {/* Custom Branding Footer */}
      <footer className="mt-12 text-center text-xs text-[#3d4a5c] py-6 border-t border-[#1f2530]">
        Built by BikashDev | Contact: contact@bikashdev.com
      </footer>
    </div>
  )
}

export default App