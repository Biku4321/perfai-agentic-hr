import { useState, useEffect } from 'react'

export default function ManagerView() {
  const [team, setTeam] = useState([])
  const [loading, setLoading] = useState(true)
  const [generatingFor, setGeneratingFor] = useState(null)
  const [selectedReview, setSelectedReview] = useState(null)

  // Hardcoding manager M001 (Vikram) for the hackathon demo
  const MANAGER_ID = 'M001'

  useEffect(() => {
    fetch(`/api/managers/${MANAGER_ID}/team`)
      .then(r => r.json())
      .then(data => {
        setTeam(data)
        setLoading(false)
      })
  }, [])

  const generateDraft = async (employeeId) => {
    setGeneratingFor(employeeId)
    try {
      const res = await fetch('/api/reviews/generate-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employee_id: employeeId, cycle_id: 'CYC-2024-H1' })
      })
      const data = await res.json()
      setSelectedReview(data)
      
      // Refresh team status
      const updatedTeam = await fetch(`/api/managers/${MANAGER_ID}/team`).then(r => r.json())
      setTeam(updatedTeam)
    } catch (err) {
      console.error(err)
    } finally {
      setGeneratingFor(null)
    }
  }

  if (loading) return <div>Loading Team Data...</div>

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold font-display">My Team</h1>
          <p className="text-[#6b7a8d]">Appraisal Cycle: H1 2024</p>
        </div>
        <button className="btn btn-primary" onClick={() => alert('Batch generation started!')}>
          Auto-Draft All Pending
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {team.map(emp => (
          <div key={emp.id} className="card flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-lg">{emp.name}</h3>
                {emp.review_status === 'completed' && <span className="badge badge-green">Done</span>}
                {emp.review_status === 'draft_generated' && <span className="badge badge-blue">Draft Ready</span>}
                {emp.review_status === 'pending' && <span className="badge badge-yellow">Pending</span>}
              </div>
              <p className="text-xs text-[#6b7a8d] mb-4">{emp.role}</p>
              
              <div className="flex gap-1 flex-wrap mb-4">
                {emp.signal_sources.map(src => (
                  <span key={src} className="text-[10px] px-2 py-1 rounded bg-[#2a3545] text-[#e8ecf0] capitalize">
                    {src}
                  </span>
                ))}
              </div>
            </div>

            <div className="border-t border-[#1f2530] pt-4 mt-2">
              {emp.review_status === 'pending' ? (
                <button 
                  onClick={() => generateDraft(emp.id)}
                  disabled={generatingFor === emp.id}
                  className="w-full btn flex justify-center bg-[#181c24] hover:border-[#00d4aa] hover:text-[#00d4aa]"
                >
                  {generatingFor === emp.id ? 'Analyzing Signals...' : '✨ Generate AI Draft'}
                </button>
              ) : (
                <button 
                  onClick={() => fetch(`/api/reviews/${emp.id}/CYC-2024-H1`).then(r=>r.json()).then(setSelectedReview)}
                  className="w-full btn flex justify-center border-[#4a9eff] text-[#4a9eff]"
                >
                  Review Draft
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Review Modal Placeholder */}
      {selectedReview && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-[#111318] border border-[#2a3545] rounded-xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">Draft Review: {selectedReview.employee_name || selectedReview.employee_id}</h2>
            <div className="text-xs text-[#00d4aa] mb-4">Grounded in: {selectedReview.evidence_sources?.join(', ') || 'work signals'}</div>
            <div className="whitespace-pre-wrap text-sm text-[#e8ecf0] font-mono bg-[#0a0b0e] p-4 rounded-lg border border-[#1f2530]">
              {selectedReview.draft || selectedReview.ai_draft}
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button className="btn" onClick={() => setSelectedReview(null)}>Close</button>
              <button className="btn btn-primary" onClick={() => setSelectedReview(null)}>Approve & Finalize</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}